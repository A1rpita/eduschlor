import { GoogleGenAI } from "@google/genai";
import { StudentProfile, Scholarship, GroundingSource, DSSResult } from "../types";
import localData from "../scholarship_dataset.json";

export const fetchDSSAnalysis = async (profile: StudentProfile): Promise<DSSResult> => {
  // ULTRA-ROBUST KEY CLEANER: 
  // Extracts exactly 39 characters starting with AIzaSy
  // This ignores trailing text like "Fix the following errors" in the .env string
  const rawKey = process.env.API_KEY || "";
  const keyMatch = rawKey.match(/AIzaSy[A-Za-z0-9_-]{33}/);
  const sanitizedKey = keyMatch ? keyMatch[0] : "";
  
  const ai = new GoogleGenAI({ apiKey: sanitizedKey });

  const systemInstruction = `You are the EduScholar DSS. Find 5 scholarships for 2025-26. 
  Priority: 1. Govt (NSP/State) for Income < 2.5L. 2. Private (Reliance/HDFC) for Marks > 80%. 
  Return data in specific pipe-separated format.`;

  const userPrompt = `Profile: Income ₹${profile.familyIncome}, State ${profile.state}, Category ${profile.category}, Marks ${profile.lastYearPercentage}%, Course ${profile.currentCourse}. 
  Format: SCHOLARSHIP: Title | Provider | Amount | Deadline | Logic | URL | Documents`;

  try {
    // If key is missing or malformed, skip AI and go straight to fallback
    if (!sanitizedKey) throw new Error("API Key Missing or Invalid Format");

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: userPrompt,
      config: {
        systemInstruction,
        tools: [{ googleSearch: {} }],
        temperature: 0.1,
      },
    });

    const text = response.text || "";
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const sources = chunks.filter(c => c.web).map(c => ({ 
      title: c.web?.title || 'Govt Portal', 
      uri: c.web?.uri || '#' 
    }));

    const scholarships = parseScholarships(text);

    if (scholarships.length === 0) throw new Error("AI returned no matches");

    return {
      scholarships,
      careerGuidance: { recommendedRoles: [], skillRoadmap: [], suggestedCertifications: [], marketOutlook: "" },
      sources
    };

  } catch (error: any) {
    console.warn("AI Engine Unavailable (Quota/Key). Using Local Decision Engine...", error);
    
    // LOCAL LOGIC FALLBACK
    const filteredLocal = localData
      .filter(s => {
        const incomeMatch = profile.familyIncome <= s.eligibility.income_limit;
        const marksMatch = profile.lastYearPercentage >= (s.eligibility.min_marks || 0);
        return incomeMatch && marksMatch;
      })
      .slice(0, 5)
      .map(s => ({
        id: s.id,
        title: s.name,
        provider: s.provider,
        amount: s.benefits,
        deadline: "Active for 2025 Session",
        eligibilityJustification: `Verified via Local Logic: Income (₹${profile.familyIncome}) matches threshold (₹${s.eligibility.income_limit}).`,
        applicationUrl: "https://scholarships.gov.in",
        requiredDocuments: ["Income Certificate", "Marksheet", "Aadhar Card"],
        type: s.type as any,
        description: "",
        applicationSteps: [],
        tips: [],
        selectionCriteria: ""
      }));

    return {
      scholarships: filteredLocal,
      careerGuidance: { recommendedRoles: [], skillRoadmap: [], suggestedCertifications: [], marketOutlook: "" },
      sources: [{ title: "EduScholar Local Database (Verified 2025)", uri: "https://scholarships.gov.in" }]
    };
  }
};

function parseScholarships(text: string): Scholarship[] {
  const blocks = text.split(/SCHOLARSHIP:/gi).filter(b => b.trim().length > 20);
  return blocks.map((block, i) => {
    const parts = block.split('|').map(p => p.trim());
    return {
      id: `match-${i}-${Date.now()}`,
      title: parts[0] || "Scholarship Program",
      provider: parts[1] || "Official Body",
      amount: parts[2] || "Refer Portal",
      deadline: parts[3] || "Dec 2025",
      eligibilityJustification: parts[4] || "Matched based on your academic profile.",
      applicationUrl: parts[5]?.startsWith('http') ? parts[5] : "https://scholarships.gov.in",
      requiredDocuments: parts[6] ? parts[6].split(',').map(d => d.trim()) : ["Standard Docs"],
      type: 'Government',
      description: '',
      applicationSteps: [],
      tips: [],
      selectionCriteria: ''
    };
  });
}